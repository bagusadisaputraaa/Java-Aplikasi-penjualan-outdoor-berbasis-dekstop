-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2020 at 12:28 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjualan`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `kd_barang` varchar(20) NOT NULL DEFAULT '',
  `nama_barang` varchar(25) NOT NULL DEFAULT '',
  `merk` varchar(20) NOT NULL DEFAULT '',
  `ukuran` varchar(10) NOT NULL DEFAULT '',
  `harga_beli` varchar(20) NOT NULL DEFAULT '',
  `harga_jual` varchar(20) NOT NULL DEFAULT '',
  `total` varchar(20) NOT NULL DEFAULT '',
  `stok` varchar(10) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kd_barang`, `nama_barang`, `merk`, `ukuran`, `harga_beli`, `harga_jual`, `total`, `stok`) VALUES
('DB01', 'carriel', 'consina', '60 l', '450000', '550000', '10', '10'),
('DB02', 'sepatu', 'consina', '40', '400000', '450000', '14', '14'),
('DB03', 'carriel', 'deuter', '36 l', '1000000', '1200000', '12', '12'),
('DB04', 'jacket', 'eiger', 'XL', '500000', '550000', '7', '8'),
('DB05', 't-shirt', 'eiger', 'L', '300000', '350000', '20', '22');

-- --------------------------------------------------------

--
-- Table structure for table `barang_masuk`
--

CREATE TABLE `barang_masuk` (
  `kd_barang_masuk` varchar(15) NOT NULL DEFAULT '',
  `tgl_barang_masuk` varchar(20) NOT NULL DEFAULT '',
  `ID_supplier` varchar(15) NOT NULL DEFAULT '',
  `nama_supplier` varchar(30) NOT NULL DEFAULT '',
  `no_pemesanan` varchar(15) NOT NULL DEFAULT '',
  `tgl_pemesanan` varchar(20) NOT NULL DEFAULT '',
  `nama_karyawan` varchar(30) NOT NULL DEFAULT '',
  `kd_barang` varchar(15) NOT NULL DEFAULT '',
  `nama_barang` varchar(25) NOT NULL DEFAULT '',
  `merk` varchar(20) NOT NULL DEFAULT '',
  `ukuran` varchar(10) NOT NULL DEFAULT '',
  `jumlah` varchar(10) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang_masuk`
--

INSERT INTO `barang_masuk` (`kd_barang_masuk`, `tgl_barang_masuk`, `ID_supplier`, `nama_supplier`, `no_pemesanan`, `tgl_pemesanan`, `nama_karyawan`, `kd_barang`, `nama_barang`, `merk`, `ukuran`, `jumlah`) VALUES
('KBM01', '1/Agustus/2019', 'IDS01', 'rossy', 'NP01', '1/Agustus/2019', 'bagus', 'DB01', 'carriel', 'consina', '60 l', '1'),
('KBM02', '1/Agustus/2019', 'IDS01', 'rossy', 'NP02', '1/Agustus/2019', 'gunawan', 'DB04', 'jacket', 'eiger', 'XL', '1'),
('KBM03', '1/Agustus/2019', 'IDS03', 'hendry', 'NP02', '1/Agustus/2019', 'gunawan', 'DB04', 'jacket', 'eiger', 'XL', '1'),
('KBM04', '1/Agustus/2019', 'IDS02', 'novi', 'NP05', '1/Agustus/2019', 'viola', 'DB05', 't-shirt', 'eiger', 'L', '2');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `NIK` varchar(15) NOT NULL DEFAULT '',
  `Nama` varchar(30) NOT NULL DEFAULT '',
  `Telepon` varchar(13) NOT NULL DEFAULT '',
  `Alamat` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`NIK`, `Nama`, `Telepon`, `Alamat`) VALUES
('2015435010', 'bagus', '089656655294', 'depok'),
('2015435011', 'gunawan', '08973949409', 'bogor'),
('2015435012', 'yuli', '089777764957', 'depok'),
('2015435013', 'hendy', '08956738398', 'jakarta'),
('2015435014', 'viola', '08967363789', 'bogor');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(15) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `ID_pelanggan` varchar(15) NOT NULL DEFAULT '',
  `Nama` varchar(30) NOT NULL DEFAULT '',
  `Telepon` varchar(13) NOT NULL DEFAULT '',
  `Alamat` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`ID_pelanggan`, `Nama`, `Telepon`, `Alamat`) VALUES
('IDP01', 'guruh', '0938590389', 'ciputat'),
('IDP02', 'supriadi', '0896759495', 'tanggerang'),
('IDP03', 'tita', '089759493859', 'cibinong'),
('IDP04', 'nurma', '08793456738', 'parung'),
('IDP05', 'agus', '085792038959', 'jakarta');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan`
--

CREATE TABLE `pemesanan` (
  `no_pemesanan` varchar(15) NOT NULL DEFAULT '',
  `tgl_pemesanan` varchar(20) NOT NULL DEFAULT '',
  `NIK` varchar(15) NOT NULL DEFAULT '',
  `nama_karyawan` varchar(30) NOT NULL DEFAULT '',
  `kd_barang` varchar(25) NOT NULL DEFAULT '',
  `nama_barang` varchar(25) NOT NULL DEFAULT '',
  `merk` varchar(10) NOT NULL DEFAULT '',
  `ukuran` varchar(10) NOT NULL DEFAULT '',
  `harga_beli` varchar(15) NOT NULL DEFAULT '',
  `jumlah` varchar(10) NOT NULL DEFAULT '',
  `total` varchar(10) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemesanan`
--

INSERT INTO `pemesanan` (`no_pemesanan`, `tgl_pemesanan`, `NIK`, `nama_karyawan`, `kd_barang`, `nama_barang`, `merk`, `ukuran`, `harga_beli`, `jumlah`, `total`) VALUES
('NP01', '1/Agustus/2019', '2015435010', 'bagus', 'DB01', 'carriel', 'consina', '60 l', '450000', '1', '10'),
('NP02', '1/Agustus/2019', '2015435011', 'gunawan', 'DB04', 'jacket', 'eiger', 'XL', '500000', '1', '7'),
('NP03', '1/Agustus/2019', '2015435012', 'yuli', 'DB03', 'carriel', 'deuter', '36 l', '1000000', '1', '12'),
('NP04', '1/Agustus/2019', '2015435013', 'hendy', 'DB03', 'carriel', 'deuter', '36 l', '1000000', '1', '12'),
('NP05', '1/Agustus/2019', '2015435014', 'viola', 'DB05', 't-shirt', 'eiger', 'L', '300000', '2', '20'),
('NP06', '6/Juni/2020', '20200606', 'banu', 'DB05', 'carriel', 'consina', 'S', '650000', '3', '30');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `no_penjualan` varchar(10) NOT NULL,
  `tgl_penjualan` varchar(30) NOT NULL DEFAULT '',
  `ID_pelanggan` varchar(10) NOT NULL,
  `nama_pelanggan` varchar(20) NOT NULL,
  `kd_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(25) NOT NULL,
  `merk` varchar(20) NOT NULL,
  `ukuran` varchar(5) NOT NULL,
  `harga_jual` varchar(10) NOT NULL,
  `jumlah` varchar(10) NOT NULL,
  `stok` varchar(20) NOT NULL DEFAULT '',
  `sisa` varchar(20) NOT NULL DEFAULT '',
  `total` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`no_penjualan`, `tgl_penjualan`, `ID_pelanggan`, `nama_pelanggan`, `kd_barang`, `nama_barang`, `merk`, `ukuran`, `harga_jual`, `jumlah`, `stok`, `sisa`, `total`) VALUES
('NP02', '1/Agustus/2019', 'IDP04', 'nurma', 'DB03', 'carriel', 'deuter', '36 l', '1200000', '2', '1', '3', '2400000'),
('NP03', '1/Agustus/2019', 'IDP01', 'guruh', 'DB01', 'carriel', 'consina', '60 l', '550000', '2', '3', '1', '1100000'),
('NP04', '1/Agustus/2019', 'IDP01', 'guruh', 'DB01', 'carriel', 'consina', '60 l', '550000', '1', '2', '3', '550000'),
('NP05', '1/Agustus/2019', 'IDP01', 'guruh', 'DB01', 'carriel', 'consina', '60 l', '550000', '5', '3', '8', '2750000'),
('NP06', '6/Juni/2020', 'IDP100', 'banu', 'DB01', 'carriel', 'consina', 'S', '650000', '2', '1', '7', '1300000');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `ID_supplier` varchar(15) NOT NULL DEFAULT '',
  `Nama` varchar(30) NOT NULL DEFAULT '',
  `Telepon` varchar(13) NOT NULL DEFAULT '',
  `Alamat` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`ID_supplier`, `Nama`, `Telepon`, `Alamat`) VALUES
('IDS01', 'rossy', '08957765476', 'bogor'),
('IDS02', 'novi', '08974902938', 'bogor'),
('IDS03', 'hendry', '08965667783', 'parung'),
('IDS04', 'jaka', '08957383949', 'ranco'),
('IDS05', 'kampleng', '08957694940', 'cilebut');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kd_barang`);

--
-- Indexes for table `barang_masuk`
--
ALTER TABLE `barang_masuk`
  ADD PRIMARY KEY (`kd_barang_masuk`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`NIK`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`ID_pelanggan`);

--
-- Indexes for table `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`no_pemesanan`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`no_penjualan`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`ID_supplier`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
